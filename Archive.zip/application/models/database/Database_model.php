<?php


/**
 * MapIgniter
 *
 * An open source GeoCMS application
 *
 * @package		MapIgniter
 * @author		Marco Afonso
 * @copyright	Copyright (c) 2012-2013-2013, Marco Afonso
 * @license		dual license, one of two: Apache v2 or GPL
 * @link		http://mapigniter.com/
 * @since		Version 1.1
 * @filesource
 */

// ------------------------------------------------------------------------

/**
 * Description of Database_model
 * 
 * @author mafonso
 */
class Database_model extends CI_Model {
    
    public function __construct() {
        parent::__construct();
        
        $this->load->library('rb');
    }
    
    public function getConfig($name = 'default') {
        return $this->redbean->getConfig($name);
    }
    
    public function selectDatabase($name = 'default') {
        $this->rb->select($name);
    }
    
    
    public function create($type)
    {
        return R::dispense($type);
    }
    
    public function save(&$bean)
    {
        if (!empty($bean->last_update)) $bean->last_update = date('Y-m-d H:i:s');
        return R::store($bean);
    }
    
    public function load($type, $id) {
        return R::load($type, $id);
    }
    
    public function find($type, $sql = ' 1 ', $values = array()) {
        return R::find($type, $sql, $values);
    }
    
    public function findOne($type, $sql = ' 1 ', $values = array()) {
        return R::findOne($type, $sql, $values);
    }
    
    public function related($bean, $type, $sql = ' true ', $values = array()) {
        return R::related($bean, $type, $sql, $values);
    }
    
    public function addTags($bean, $tags) {
        return R::addTags($bean, $tags);
    }
    
    public function setTags($bean, $tags) {
        return R::tag($bean, $tags);
    }
    
    public function getTags($bean) {
        return R::tag($bean);
    }
    
    public function findByTags($type, $tags) {
        return R::tagged( $type, $tags );
    }
    
    public function delete($type, $ids) {
        $beans = R::batch($type, $ids);
        foreach ($beans as $bean) R::trash($bean);
    }
    
    public function loadAll($type, $ids) {
        return R::batch($type, $ids);
    }
    
    public function exportAll($beans, $parents) {
        return R::exportAll($beans, $parents);
    }
    
    public function exec($sql, $values = array()) {
        return R::exec($sql, $values);
    }
    
    public function getAll($sql, $values = array()) {
        return R::getAll($sql, $values);
    }
    
    public function getRow($sql, $values = array()) {
        return R::getRow($sql, $values);
    }
    
    public function isOwner($account, $entity, $id) {
        $bean = $this->load($entity, $id);
        if ($account == $bean->fetchAs('account')->owner) return true;
        return false;
    }
    
    public function createPDO($dsn, $user, $pass, $silent = false) {
        $pdo = new PDO($dsn, $user, $pass);
        if ($silent) $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_SILENT);
        return $pdo;
    }
    
    public function pdoExec($pdo, $sql) {
        return $pdo->exec($sql);
    }

    
}

?>
