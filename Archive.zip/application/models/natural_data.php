<?php
class Natural_data extends CI_Model {
    
    public function __construct() {
        parent::__construct();
        
    }
    function get_objects($table = 'countries',$id = false , $simplify = 0,$fields = false,$where = false,$limit = 50,$offset = 0)
    {
        if($simplify == false) $simplify = 0;
        
        if($fields == 'all'):
        
            $this->db->select('*, ST_AsGeoJSON(ST_Simplify(geom, '.$simplify.')) as geojson', false);
            
        elseif($fields != false):
            $fields = explode('-',$fields);
            $this->db->select(implode($fields,',').', ST_AsGeoJSON(ST_Simplify(geom, '.$simplify.')) as geojson', false);
        else:
            $this->db->select('id, ST_AsGeoJSON(ST_Simplify(geom, '.$simplify.')) as geojson', false);
        endif;
        
        if($id):
            $this->db->where('id', $id);
        
        elseif($where):
            $where = explode('-',$where);
            $this->db->where($where[0], $where[1]);
        endif;
        
        $this->db->limit($limit, $offset);
        
        $q = $this->db->get($table)->result_array();
        return $q;
    }
}
?>
